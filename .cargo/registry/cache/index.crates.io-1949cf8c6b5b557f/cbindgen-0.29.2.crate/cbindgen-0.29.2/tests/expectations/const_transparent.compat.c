#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

typedef uint8_t TransparentStruct;
#define TransparentStruct_ASSOC_STRUCT_FOO 1
#define TransparentStruct_ASSOC_STRUCT_BAR 2


typedef uint8_t TransparentTupleStruct;

#define STRUCT_FOO 4

#define STRUCT_BAR 5




