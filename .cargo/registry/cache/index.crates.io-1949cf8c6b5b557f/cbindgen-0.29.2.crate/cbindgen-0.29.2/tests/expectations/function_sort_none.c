#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

void C(void);

void B(void);

void D(void);

void A(void);
