//! # Example: pacman-like CLI (Builder API)
//!
//! ```rust
#![doc = include_str!("../../examples/pacman.rs")]
//! ```
//!
#![doc = include_str!("../../examples/pacman.md")]
