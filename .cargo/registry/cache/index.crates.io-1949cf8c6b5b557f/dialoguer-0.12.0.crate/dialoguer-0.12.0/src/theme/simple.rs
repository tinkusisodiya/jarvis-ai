use crate::theme::Theme;

/// The default theme.
pub struct SimpleTheme;

impl Theme for SimpleTheme {}
