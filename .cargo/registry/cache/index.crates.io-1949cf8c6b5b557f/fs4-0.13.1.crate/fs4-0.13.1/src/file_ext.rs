cfg_sync!(
    pub(crate) mod sync_impl;
);

cfg_async!(
    pub(crate) mod async_impl;
);
