use indoc::indoc;

fn main() {
    let world = "world";
    println!(indoc!("Hello {world}"));
}
