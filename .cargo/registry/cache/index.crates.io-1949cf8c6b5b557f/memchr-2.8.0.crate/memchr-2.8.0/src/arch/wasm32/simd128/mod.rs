/*!
Algorithms for the `wasm32` target using 128-bit vectors via simd128.
*/

pub mod memchr;
pub mod packedpair;
