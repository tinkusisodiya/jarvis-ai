# Changelog

## 0.6.6

- Update bzip2 to 0.5

## 0.6.5

- Update mailparse to 0.16

## 0.6.4

- Update fs-err to 3.0

## 0.6.3

- Disable `bzip2` and `time` feature of the `zip` crate by default. `bzip2` support was already behind a feature, and `time` was unused.
