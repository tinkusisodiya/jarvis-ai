# syscall

This crate contains the system call numbers and Rust wrappers for the inline Assembly code of system calls.

[![MIT licensed](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE)
[![crates.io](http://meritbadge.herokuapp.com/redox_syscall)](https://crates.io/crates/redox_syscall)
[![docs.rs](https://docs.rs/redox_syscall/badge.svg)](https://docs.rs/redox_syscall)
