Benchmarks for this crate have been moved into the rebar project:
https://github.com/BurntSushi/rebar
