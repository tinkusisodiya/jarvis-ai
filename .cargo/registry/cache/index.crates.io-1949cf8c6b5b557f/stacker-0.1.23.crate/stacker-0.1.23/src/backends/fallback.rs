#[inline(always)]
pub unsafe fn guess_os_stack_limit() -> Option<usize> {
    None
}
